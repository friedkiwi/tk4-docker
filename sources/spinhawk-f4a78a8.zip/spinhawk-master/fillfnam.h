/* FILLFNAM.H   (c) Copyright Volker Bandke, 2003-2006               */
/*              Hercules filename completion functions               */

#ifndef __FILLFNAM_H__
#define __FILLFNAM_H__

int tab_pressed(char *cmdlinefull, int *cmdoffset);

#endif
