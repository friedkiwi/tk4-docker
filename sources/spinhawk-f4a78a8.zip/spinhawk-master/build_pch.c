/* BUILD_PCH  (c)Copyright Ivan Warren, 2005-2009                    */
/*            Dummy module for building pre-compiled header files    */

#include "hstdinc.h"
